/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Customer;

import static Customer.Customer.getLatestOrderDetails;
import static Customer.Customer.isValidRating;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Customer UI - Menu Panel
 */
public class CustomerUI extends javax.swing.JFrame {

    private static final String MENU_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Food_Menu.txt/";
    private static final String ORDER_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/orderlist.txt/";

    private Customer customer;  // Reference to Customer object

    public CustomerUI(String userID) {
        initComponents();
        this.customer = new Customer(userID); // Load customer details
        loadMenuItems();
        refreshOrderList();
    }

    private void checkFilePath(String filePath) {
        File file = new File(filePath);
        System.out.println("Checking file path: " + file.getAbsolutePath());

        if (!file.exists()) {
            JOptionPane.showMessageDialog(this, "Error: " + filePath + " not found!\nExpected Path: " + file.getAbsolutePath(),
                    "File Missing", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Load food items from Food_Menu.txt into FoodlistTable
    private void loadMenuItems() {
        DefaultTableModel model = (DefaultTableModel) FoodlistTable.getModel();
        model.setRowCount(0); // Clear table

        checkFilePath(MENU_FILE); // Check file path before reading

        try (BufferedReader reader = new BufferedReader(new FileReader(MENU_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Reading Food_Menu.txt: " + line); // Debugging
                String[] data = line.split(",");
                if (data.length >= 5) {
                    model.addRow(new Object[]{data[2], data[3], data[4], data[5]});  // Food ID, Name, Price, Review
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading menu: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Refresh OrderlistTable by reading orderlist.txt
    private void refreshOrderList() {
        DefaultTableModel model = (DefaultTableModel) OrderlistTable.getModel();
        model.setRowCount(0); // Clear table

        checkFilePath(ORDER_FILE); // Check file path before reading

        try (BufferedReader reader = new BufferedReader(new FileReader(ORDER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Reading orderlist.txt: " + line); // Debugging
                String[] data = line.split(",");
                if (data.length >= 8) {
                    model.addRow(new Object[]{data[0], data[1], data[6], data[7]});  // Food ID, Name, Total Price, Delivery Price
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading orders: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Step2
    private void loadPaymentDetails() {
        DefaultTableModel model = (DefaultTableModel) Paymentlist.getModel();
        model.setRowCount(0); // Clear table before loading new data

        // Get logged-in user ID
        String userId = customer.getCustomerID();
        System.out.println("Logged-in User ID: " + userId); // Debugging output

        // Get user balance from UserOnline.txt
        double balance = customer.getBalanceFromUserOnline(userId);
        System.out.println("Retrieved Balance: RM " + balance); // Debugging output

        List<String[]> orders = customer.getOrderList();

        if (orders.isEmpty()) {
            System.out.println("No orders found for user: " + userId); // Debugging output
        }

        double totalPayment = 0.0;

        for (String[] order : orders) {
            if (order.length >= 8) {
                double price = Double.parseDouble(order[6]);  // Price
                double deliveryFee = Double.parseDouble(order[7]);  // Delivery fee
                double total = price + deliveryFee;  // Total price per order
                totalPayment += total;  // Accumulate total payment

                // Debugging output
                System.out.println("Adding Order: " + Arrays.toString(order));

                // Add order details to the table
                model.addRow(new Object[]{
                    order[2], // User ID
                    order[3], // User Name
                    order[1], // Food Name
                    order[0], // Food ID
                    order[6], // Price
                    order[7], // Delivery Fee
                    total, // Total Amount
                    balance // Balance
                });
            } else {
                System.out.println("Skipping invalid order entry: " + Arrays.toString(order)); // Debugging output
            }
        }

        // Force UI to refresh after adding rows
        Paymentlist.repaint();
        Paymentlist.revalidate();

        System.out.println("Total Payment Calculated: RM " + totalPayment); // Debugging output
    }

/////////////////////////////////////////////////////////
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        Menu = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        OrderlistTable = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        Add = new javax.swing.JButton();
        Cancel = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        FoodIDText = new javax.swing.JTextField();
        NextPanel2 = new javax.swing.JButton();
        RenewOrderlist = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        FoodlistTable = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        Pay = new javax.swing.JButton();
        NextPanel3 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        Paymentlist = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        TotalAmountLabel = new javax.swing.JTable();
        Refresh = new javax.swing.JButton();
        RefreshBalance = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Status = new javax.swing.JTable();
        Check = new javax.swing.JButton();
        TakeOrder = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        TextRunner = new javax.swing.JTextField();
        TextVendor = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Submit = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        TextComplain = new javax.swing.JTextField();
        Complain = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Orderhistory = new javax.swing.JTable();
        Check2 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        Transactionhistory = new javax.swing.JTable();
        Check3 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel7.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Food list");

        OrderlistTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Food ID", "Food Name", "Total price", "Delivery price"
            }
        ));
        jScrollPane1.setViewportView(OrderlistTable);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Order list");

        Add.setText("Add");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });

        Cancel.setText("Cancel");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });

        jLabel13.setText("Enter the Food ID");

        FoodIDText.setText("jTextField4");
        FoodIDText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FoodIDTextActionPerformed(evt);
            }
        });

        NextPanel2.setText("Next");
        NextPanel2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextPanel2ActionPerformed(evt);
            }
        });

        RenewOrderlist.setText("Renew Order list");
        RenewOrderlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RenewOrderlistActionPerformed(evt);
            }
        });

        FoodlistTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Food ID", "Food Name", "Review"
            }
        ));
        jScrollPane7.setViewportView(FoodlistTable);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel13)
                            .addComponent(Add))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(FoodIDText, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(Cancel)))))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel8))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(RenewOrderlist)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(NextPanel2))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(168, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(FoodIDText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add)
                            .addComponent(Cancel)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(RenewOrderlist)
                            .addComponent(NextPanel2))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Menu.addTab("Menu", jPanel3);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Payment Statement");

        Pay.setText("Pay");
        Pay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PayActionPerformed(evt);
            }
        });

        NextPanel3.setText("Next");
        NextPanel3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextPanel3ActionPerformed(evt);
            }
        });

        Paymentlist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "User ID", "User Name", "Food Name", "Food ID", "User Name", "Price", "Delivery Fee"
            }
        ));
        jScrollPane3.setViewportView(Paymentlist);

        TotalAmountLabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Total Amount", "Balance"
            }
        ));
        jScrollPane2.setViewportView(TotalAmountLabel);

        Refresh.setText("Refresh Statement");
        Refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshActionPerformed(evt);
            }
        });

        RefreshBalance.setText("Refresh Balance");
        RefreshBalance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshBalanceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 710, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(Pay)
                                .addGap(78, 78, 78)
                                .addComponent(Refresh)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(RefreshBalance)
                                .addGap(19, 19, 19)))
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(NextPanel3))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Pay)
                    .addComponent(NextPanel3)
                    .addComponent(Refresh)
                    .addComponent(RefreshBalance))
                .addGap(20, 20, 20))
        );

        Menu.addTab("Payment", jPanel4);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Check status");

        Status.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Order ID", "Food ID", "Food Name", "User ID", "User Name", "Runner ID", "Runner Name", "Status"
            }
        ));
        jScrollPane4.setViewportView(Status);

        Check.setText("Check status");
        Check.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckActionPerformed(evt);
            }
        });

        TakeOrder.setText("Take order");
        TakeOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TakeOrderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(Check)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TakeOrder))
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 873, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Check)
                    .addComponent(TakeOrder))
                .addGap(27, 27, 27))
        );

        Menu.addTab("Check Status", jPanel5);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Review or complain");

        TextRunner.setText("jTextField1");

        TextVendor.setText("jTextField2");

        jLabel9.setText("Enter the rate for runner(1~5)");

        jLabel10.setText("Enter the rate for food (1~5)");

        Submit.setText("Submit");
        Submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitActionPerformed(evt);
            }
        });

        jButton6.setText("Next");

        jLabel11.setText("Complain");

        TextComplain.setText("jTextField3");

        Complain.setText("Complain");
        Complain.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComplainActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Submit)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(TextRunner, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                                    .addComponent(TextVendor)
                                    .addComponent(TextComplain)))
                            .addComponent(Complain))
                        .addGap(45, 45, 45)
                        .addComponent(jButton6)))
                .addContainerGap(512, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextRunner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextVendor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addComponent(Submit)
                .addGap(28, 28, 28)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11)
                    .addComponent(TextComplain, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Complain)
                    .addComponent(jButton6))
                .addContainerGap(126, Short.MAX_VALUE))
        );

        Menu.addTab("Review/complain", jPanel6);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("Check order history");

        Orderhistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Order ID", "Food ID", "Food Name", "User ID", "User Name", "Vendor ID", "Runner ID", "Total price", "Delivery price", "Status"
            }
        ));
        jScrollPane5.setViewportView(Orderhistory);

        Check2.setText("Check");
        Check2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Check2ActionPerformed(evt);
            }
        });

        jButton9.setText("Next");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 988, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(Check2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton9)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 142, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Check2)
                    .addComponent(jButton9))
                .addGap(24, 24, 24))
        );

        Menu.addTab("Order history", jPanel7);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setText("Transaction history");

        Transactionhistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "User ID", "User Name", "Order ID", "Amount"
            }
        ));
        jScrollPane6.setViewportView(Transactionhistory);

        Check3.setText("Check");
        Check3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Check3ActionPerformed(evt);
            }
        });

        jButton11.setText("Back to Menu");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 988, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Check3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton11))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Check3)
                    .addComponent(jButton11))
                .addContainerGap(140, Short.MAX_VALUE))
        );

        Menu.addTab("Transaction history", jPanel1);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setText("WJUN BEST FOOD ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(297, 297, 297)
                .addComponent(jLabel6)
                .addContainerGap(506, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 988, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Menu))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void PayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PayActionPerformed
        double totalPayment = customer.getTotalPayment();

        if (totalPayment == 0) {
            JOptionPane.showMessageDialog(this, "No items in cart to pay.", "Payment Failed", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Generate a unique Order ID (e.g., using current time)
        String orderId = "O" + System.currentTimeMillis();

        // Get orders from orderlist.txt for the current user
        List<String[]> orders = customer.getOrderList();

        // Write the confirmed orders to Order.txt and log the transaction in Transaction_history.txt
        try (FileWriter orderWriter = new FileWriter("Order.txt", true); FileWriter historyWriter = new FileWriter("Transaction_history.txt", true)) {

            for (String[] order : orders) {
                if (order.length >= 7) {
                    // Create the order line with all required fields.
                    // Note: order array from orderlist.txt is assumed to have:
                    // [Food ID, Food Name, User ID, User Name, Vendor ID, Vendor Name, Total Price, Delivery Price]
                    String orderDetails = String.join(",",
                            orderId, // Generated Order ID
                            order[0], // Food ID
                            order[1], // Food Name
                            order[2], // User ID
                            order[3], // User Name
                            order[4], // Vendor ID
                            order[5], // Vendor Name
                            "Null", // Runner ID (initially null)
                            "Null", // Runner Name (initially null)
                            order[6], // Total Price
                            order[7], // Delivery Price
                            "Preparing" // Status
                    );
                    orderWriter.write(orderDetails + "\n");

                    // Log the transaction in Transaction_history.txt
                    String transactionDetails = String.join(",",
                            order[2], // User ID
                            order[3], // User Name
                            orderId, // Order ID
                            String.valueOf(totalPayment) // Total amount paid
                    );
                    historyWriter.write(transactionDetails + "\n");
                }
            }
            JOptionPane.showMessageDialog(this, "Payment Successful! Order ID: " + orderId);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error processing payment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        /// Clear orderlist.txt and Transaction_bill.txt (empty them)
        try {
            FileWriter clearOrderList = new FileWriter("orderlist.txt", false);
            FileWriter clearTransactionBill = new FileWriter("Transaction_bill.txt", false);

            clearOrderList.close();
            clearTransactionBill.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error clearing order files: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Optionally, refresh the Payment table display here
        loadPaymentDetails();
    }//GEN-LAST:event_PayActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
        String foodID = JOptionPane.showInputDialog("Enter Food ID to cancel:");

        if (foodID != null && !foodID.trim().isEmpty()) {
            boolean success = customer.cancelOrder(foodID);
            if (success) {
                JOptionPane.showMessageDialog(this, "Order canceled successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadPaymentDetails();  // Refresh table after canceling order
            } else {
                JOptionPane.showMessageDialog(this, "Order not found or could not be canceled.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_CancelActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        int selectedRow = FoodlistTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a food item!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String foodID = FoodlistTable.getValueAt(selectedRow, 0).toString();

        boolean success = customer.addOrder(foodID);
        if (success) {
            JOptionPane.showMessageDialog(this, "Order added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshOrderList(); // Update order list table
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add order!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_AddActionPerformed

    private void FoodIDTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FoodIDTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FoodIDTextActionPerformed

    private void RenewOrderlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RenewOrderlistActionPerformed
        refreshOrderList();
    }//GEN-LAST:event_RenewOrderlistActionPerformed

    private void NextPanel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextPanel2ActionPerformed
        JOptionPane.showMessageDialog(this, "Moving to Payment Panel!", "Info", JOptionPane.INFORMATION_MESSAGE);
        // Code to switch to the Payment Panel (Step 2)
    }//GEN-LAST:event_NextPanel2ActionPerformed

    private void NextPanel3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextPanel3ActionPerformed
        JOptionPane.showMessageDialog(this, "Moving to Check Status Panel!", "Info", JOptionPane.INFORMATION_MESSAGE);
        // Code to switch panel
    }//GEN-LAST:event_NextPanel3ActionPerformed

    private void RefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshActionPerformed
        loadPaymentDetails();  // Reload data from order list
        System.out.println("Payment details refreshed.");
    }//GEN-LAST:event_RefreshActionPerformed

    private void RefreshBalanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshBalanceActionPerformed
        // Get the DefaultTableModel for the TotalAmountLabel table
        DefaultTableModel model = (DefaultTableModel) TotalAmountLabel.getModel();

        // Clear the table before updating
        model.setRowCount(0);

        // Get the current logged-in user ID
        String userId = customer.getCustomerID();

        // Get the updated balance from UserOnline.txt
        double updatedBalance = customer.getBalanceFromUserOnline(userId);

        // Get the updated total payment
        double totalPayment = customer.getTotalPayment();

        // Format values for display
        String formattedBalance = String.format("%.2f", updatedBalance);
        String formattedTotal = String.format("%.2f", totalPayment);

        // Debugging messages
        System.out.println("Retrieved Balance: RM " + formattedBalance);
        System.out.println("Total Payment Calculated: RM " + formattedTotal);

        // Add the updated values to the table
        model.addRow(new Object[]{"", "", "", "", "", "TOTAL", formattedTotal, formattedBalance});

        // Debugging message
        System.out.println("Balance and Total Payment table refreshed.");
    }//GEN-LAST:event_RefreshBalanceActionPerformed

    private void CheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckActionPerformed
        DefaultTableModel model = (DefaultTableModel) Status.getModel();
        model.setRowCount(0); // Clear table before loading new data

        try (BufferedReader reader = new BufferedReader(new FileReader("Order.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");

                // Debugging output to check if Order ID & Status are read correctly
                System.out.println("Reading Order: " + Arrays.toString(order));

                if (order.length >= 12) {
                    model.addRow(new Object[]{
                        order[0], // Order ID
                        order[1], // Food ID
                        order[2], // Food Name
                        order[3], // User ID
                        order[4], // User Name
                        order[7], // Runner ID
                        order[8], // Runner Name
                        order[11] // Status
                    });
                } else {
                    System.out.println("Skipping Invalid Order Entry: " + Arrays.toString(order));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Order.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        System.out.println("Order Status Table Refreshed");
    }//GEN-LAST:event_CheckActionPerformed

    private void TakeOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TakeOrderActionPerformed
        List<String> updatedOrders = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("Order.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");

                // Check if the order is Arrived
                if (order.length >= 12 && "Arrived".equals(order[11])) {
                    order[11] = "Complete"; // Update status to Complete
                    JOptionPane.showMessageDialog(this, "Order marked as Complete!");
                }

                updatedOrders.add(String.join(",", order));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Order.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Rewrite Order.txt with updated status
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Order.txt"))) {
            for (String order : updatedOrders) {
                writer.write(order);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating Order.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_TakeOrderActionPerformed

    private void ComplainActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComplainActionPerformed
        String[] latestOrder = getLatestOrderDetails(); // Fetch latest Order details from Order.txt
        if (latestOrder == null) {
            JOptionPane.showMessageDialog(this, "No completed order found to complain about.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String orderId = latestOrder[0]; // Order ID
        String foodId = latestOrder[1]; // Food ID
        String foodName = latestOrder[2]; // Food Name
        String userId = latestOrder[3]; // User ID
        String userName = latestOrder[4]; // User Name
        String vendorId = latestOrder[5]; // Vendor ID
        String vendorName = latestOrder[6]; // Vendor Name
        String runnerId = latestOrder[7]; // Runner ID
        String runnerName = latestOrder[8]; // Runner Name

        String complainText = TextComplain.getText().trim();
        if (complainText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a complaint.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Save Complaint
            try (FileWriter writer = new FileWriter("Complain.txt", true)) {
                writer.write(orderId + "," + foodId + "," + foodName + "," + userId + "," + userName + "," + vendorId + "," + vendorName + "," + runnerId + "," + runnerName + "," + complainText + ",not resolved\n");
            }

            JOptionPane.showMessageDialog(this, "Complaint submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error processing complaint: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_ComplainActionPerformed

    private void SubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitActionPerformed
        String[] latestOrder = getLatestOrderDetails(); // Fetch latest Order details from Order.txt
        if (latestOrder == null) {
            JOptionPane.showMessageDialog(this, "No completed order found to review.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String orderId = latestOrder[0]; // Order ID
        String foodId = latestOrder[1]; // Food ID
        String foodName = latestOrder[2]; // Food Name
        String userId = latestOrder[3]; // User ID
        String userName = latestOrder[4]; // User Name
        String vendorId = latestOrder[5]; // Vendor ID
        String vendorName = latestOrder[6]; // Vendor Name
        String runnerId = latestOrder[7]; // Runner ID
        String runnerName = latestOrder[8]; // Runner Name

        String runnerRating = TextRunner.getText().trim();
        String vendorRating = TextVendor.getText().trim();

        if (!isValidRating(runnerRating) || !isValidRating(vendorRating)) {
            JOptionPane.showMessageDialog(this, "Please enter a rating between 1 and 5.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Save Runner Review
            try (FileWriter writer = new FileWriter("Review_runner.txt", true)) {
                writer.write(orderId + "," + foodId + "," + foodName + "," + userId + "," + userName + "," + runnerId + "," + runnerName + "," + runnerRating + "\n");
            }

            // Save Vendor Review
            try (FileWriter writer = new FileWriter("Review_vendor.txt", true)) {
                writer.write(orderId + "," + foodId + "," + foodName + "," + userId + "," + userName + "," + vendorId + "," + vendorName + "," + vendorRating + "\n");
            }

            JOptionPane.showMessageDialog(this, "Review submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error processing review: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_SubmitActionPerformed

    private void Check2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Check2ActionPerformed
        DefaultTableModel model = (DefaultTableModel) Orderhistory.getModel();
        model.setRowCount(0); // Clear table before loading new data

        try (BufferedReader reader = new BufferedReader(new FileReader("Order.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");

                // Debugging output to check if the Order.txt is being read correctly
                System.out.println("Reading Order History: " + Arrays.toString(order));

                if (order.length >= 12 && "Complete".equalsIgnoreCase(order[11])) {
                    model.addRow(new Object[]{
                        order[0], // Order ID
                        order[1], // Food ID
                        order[2], // Food Name
                        order[3], // User ID
                        order[4], // User Name
                        order[5], // Vendor ID
                        order[7], // Runner ID
                        order[9], // Total Price
                        order[10], // Delivery Price
                        order[11] // Status (Only shows "Complete")
                    });
                } else {
                    System.out.println("Skipping Non-Completed Order: " + Arrays.toString(order));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Order.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        System.out.println("Order History Table Refreshed");
    }//GEN-LAST:event_Check2ActionPerformed

    private void Check3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Check3ActionPerformed
        DefaultTableModel model = (DefaultTableModel) Transactionhistory.getModel();
        model.setRowCount(0); // Clear table before loading new data

        try (BufferedReader reader = new BufferedReader(new FileReader("Transaction_history.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] transaction = line.split(",");

                // Debugging output to check if Transaction_history.txt is being read correctly
                System.out.println("Reading Transaction History: " + Arrays.toString(transaction));

                if (transaction.length >= 4) {
                    model.addRow(new Object[]{
                        transaction[0], // User ID
                        transaction[1], // User Name
                        transaction[2], // Order ID
                        transaction[3] // Amount
                    });
                } else {
                    System.out.println("Skipping Invalid Transaction Entry: " + Arrays.toString(transaction));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Transaction_history.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        System.out.println("Transaction History Table Refreshed");
    }//GEN-LAST:event_Check3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new CustomerUI("C001").setVisible(true));
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Cancel;
    private javax.swing.JButton Check;
    private javax.swing.JButton Check2;
    private javax.swing.JButton Check3;
    private javax.swing.JButton Complain;
    private javax.swing.JTextField FoodIDText;
    private javax.swing.JTable FoodlistTable;
    private javax.swing.JTabbedPane Menu;
    private javax.swing.JButton NextPanel2;
    private javax.swing.JButton NextPanel3;
    private javax.swing.JTable Orderhistory;
    private javax.swing.JTable OrderlistTable;
    private javax.swing.JButton Pay;
    private javax.swing.JTable Paymentlist;
    private javax.swing.JButton Refresh;
    private javax.swing.JButton RefreshBalance;
    private javax.swing.JButton RenewOrderlist;
    private javax.swing.JTable Status;
    private javax.swing.JButton Submit;
    private javax.swing.JButton TakeOrder;
    private javax.swing.JTextField TextComplain;
    private javax.swing.JTextField TextRunner;
    private javax.swing.JTextField TextVendor;
    private javax.swing.JTable TotalAmountLabel;
    private javax.swing.JTable Transactionhistory;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    // End of variables declaration//GEN-END:variables
}
