/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;

import java.io.*;
import java.util.*;

public class Customer {

    private String customerID;
    private String name;
    private double balance;

    private static final String ORDER_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Order.txt/";
    private static final String TRANSACTION_BILL_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Transaction_bill.txt";
    private static final String TRANSACTION_HISTORY_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Transaction_history.txt/";
    private static final String USER_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/User.txt/";
    private static final String ORDER_LIST_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/orderlist.txt/";
    private static final String FOOD_MENU_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Food_Menu.txt/";
    private static final String USER_ONLINE_FILE = "C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/UserOnline.txt/";

    // Constructor - Loads user details from User.txt
    public Customer(String userID) {
        this.customerID = userID;
        loadUserDetails(userID);
    }

    // Constructor - Loads logged-in user details
    public Customer() {
        loadCurrentUser();
        this.balance = 50.0; // Default balance (for testing)
    }

    // Load user details from User.txt
    private void loadUserDetails(String userID) {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length >= 2 && details[0].trim().equals(userID)) {
                    this.name = details[1].trim();
                    break;
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading user details: " + e.getMessage());
        }
    }

    // Load current logged-in user from UserOnline.txt
    private void loadCurrentUser() {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER_ONLINE_FILE))) {
            String line;
            if ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 2) {
                    this.customerID = data[0].trim();
                    this.name = data[1].trim();
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading current user: " + e.getMessage());
        }
    }

    // Fetch current logged-in user from UserOnline.txt
    public static Customer getCurrentUser() {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER_ONLINE_FILE))) {
            String line;
            if ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 2) {
                    return new Customer(data[0].trim());
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading current user: " + e.getMessage());
        }
        return null;
    }

    // Getters
    public String getCustomerID() {
        return customerID;
    }

    public String getName() {
        return name;
    }

    //  Add This to Customer.java (Handles Data Processing for Review & Complain)
    public static String[] getLatestOrderDetails() {
        String[] latestOrder = null;
        try (BufferedReader reader = new BufferedReader(new FileReader("Order.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");
                if (order.length >= 12) {
                    latestOrder = order; // Store the latest order details
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading Order.txt: " + e.getMessage());
        }
        return latestOrder;
    }

    public static boolean isValidRating(String rating) {
        try {
            int rate = Integer.parseInt(rating);
            return rate >= 1 && rate <= 5;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void saveReview(String orderId, String foodId, String foodName, String userId, String userName, String vendorId, String vendorName, String runnerId, String runnerName, String runnerRating, String vendorRating) throws IOException {
        try (FileWriter writer = new FileWriter("Review_runner.txt", true)) {
            writer.write(orderId + "," + foodId + "," + foodName + "," + userId + "," + userName + "," + runnerId + "," + runnerName + "," + runnerRating + "\n");
        }
        try (FileWriter writer = new FileWriter("Review_vendor.txt", true)) {
            writer.write(orderId + "," + foodId + "," + foodName + "," + userId + "," + userName + "," + vendorId + "," + vendorName + "," + vendorRating + "\n");
        }
    }

    public static void saveComplain(String orderId, String foodId, String foodName, String userId, String userName, String vendorId, String vendorName, String runnerId, String runnerName, String complainText) throws IOException {
        try (FileWriter writer = new FileWriter("Complain.txt", true)) {
            writer.write(orderId + "," + foodId + "," + foodName + "," + userId + "," + userName + "," + vendorId + "," + vendorName + "," + runnerId + "," + runnerName + "," + complainText + ",not resolved\n");
        }
    }

    // Read and display Food Menu from Food_Menu.txt
    public static List<String[]> getFoodMenu() {
        List<String[]> foodList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FOOD_MENU_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length >= 5) {
                    foodList.add(details); // Add food details as array
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading food menu: " + e.getMessage());
        }
        return foodList;
    }

    // Read and display the order list for the logged-in customer from orderlist.txt
    public List<String[]> getOrderList() {
        List<String[]> orderList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDER_LIST_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");
                if (order.length >= 7 && order[2].equals(this.customerID)) {
                    orderList.add(order);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading order list: " + e.getMessage());
        }
        return orderList;
    }

    // Calculate total payment for the logged-in user
    public double getTotalPayment() {
        double total = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDER_LIST_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");
                if (order.length >= 7 && order[2].equals(this.customerID)) {
                    total += Double.parseDouble(order[6]) + Double.parseDouble(order[7]); // Total Price + Delivery Price
                }
            }
        } catch (IOException e) {
            System.err.println("Error calculating total payment: " + e.getMessage());
        }
        return total;
    }

    public double getBalanceFromUserOnline(String userId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER_ONLINE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(","); // Split by comma
                if (userData.length >= 3 && userData[0].equals(userId)) {
                    return Double.parseDouble(userData[2]); // Get balance from third column
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading UserOnline.txt: " + e.getMessage());
        }
        return 0.0; // Default balance if not found
    }

    // Process payment
    public boolean processPayment() {
        double totalPayment = getTotalPayment(); // Get total payment

        // Proceed with payment process without checking balance
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDER_LIST_FILE)); FileWriter billWriter = new FileWriter(TRANSACTION_BILL_FILE, true); FileWriter historyWriter = new FileWriter(TRANSACTION_HISTORY_FILE, true); FileWriter orderWriter = new FileWriter(ORDER_FILE, true)) {

            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");
                if (order.length >= 7 && order[2].equals(this.customerID)) {
                    billWriter.write(line + "\n"); // Write to Transaction_bill.txt
                    historyWriter.write(line + "\n"); // Write to Transaction_history.txt
                    orderWriter.write(line + ",PAID\n"); // Write to Order.txt
                }
            }
        } catch (IOException e) {
            System.err.println("Error processing payment: " + e.getMessage());
            return false;
        }

        clearOrders(); // Remove processed orders
        System.out.println("Payment completed successfully.");
        return true;
    }

    // Add new order to orderlist.txt
    public boolean addOrder(String foodID) {
        String foodName = null;
        double price = 0.0;
        double deliveryPrice = 5.0;  // Default delivery price

        // Read food details from Food_Menu.txt
        try (BufferedReader reader = new BufferedReader(new FileReader(FOOD_MENU_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length >= 5 && details[2].trim().equals(foodID)) {
                    foodName = details[3].trim();
                    price = Double.parseDouble(details[4].trim());
                    break;
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading food menu: " + e.getMessage());
            return false;
        }

        if (foodName == null) {
            System.out.println("Food ID not found.");
            return false;
        }

        // Append order to orderlist.txt
        try (FileWriter writer = new FileWriter(ORDER_LIST_FILE, true)) {
            writer.write(foodID + "," + foodName + "," + this.customerID + "," + this.name + ",V001,WJUN," + price + "," + deliveryPrice + "\n");
            return true;
        } catch (IOException e) {
            System.err.println("Error adding order: " + e.getMessage());
            return false;
        }
    }

    public void submitReview(String orderId, String foodId, String foodName, String runnerId, String runnerName, String vendorId, String vendorName, int runnerRating, int vendorRating) {
        saveToFile("C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Review_runner.txt",
                orderId + "," + foodId + "," + foodName + "," + this.customerID + "," + this.name + "," + runnerId + "," + runnerName + "," + runnerRating);

        saveToFile("C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Review_vendor.txt",
                orderId + "," + foodId + "," + foodName + "," + this.customerID + "," + this.name + "," + vendorId + "," + vendorName + "," + vendorRating);
    }

    public void submitComplaint(String orderId, String foodId, String foodName, String runnerId, String runnerName, String vendorId, String vendorName, String complaintText) {
        saveToFile("C:/Users/User/Netbeans/FoodOrderingSystem_Ant/src/foodorderingsystem_ant/Complain.txt",
                orderId + "," + foodId + "," + foodName + "," + this.customerID + "," + this.name + "," + vendorId + "," + vendorName + "," + runnerId + "," + runnerName + "," + complaintText + ",not resolved");
    }

    private void saveToFile(String filePath, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(content);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    private void updateUserBalance(String userId, double newBalance) {
        List<String> updatedUsers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(USER_ONLINE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length >= 3 && userData[0].equals(userId)) {
                    userData[2] = String.valueOf(newBalance); // Update balance
                }
                updatedUsers.add(String.join(",", userData));
            }
        } catch (IOException e) {
            System.out.println("Error reading UserOnline.txt: " + e.getMessage());
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USER_ONLINE_FILE))) {
            for (String user : updatedUsers) {
                writer.write(user);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing UserOnline.txt: " + e.getMessage());
        }
    }

    // Clear orders after successful payment
    private void clearOrders() {
        List<String> remainingOrders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDER_LIST_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");
                if (!order[2].equals(this.customerID)) {
                    remainingOrders.add(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading orders: " + e.getMessage());
        }

        try (FileWriter writer = new FileWriter(ORDER_LIST_FILE)) {
            for (String order : remainingOrders) {
                writer.write(order + "\n");
            }
        } catch (IOException e) {
            System.err.println("Error updating order list: " + e.getMessage());
        }
    }

    // Cancel order by removing the entry from orderlist.txt
    public boolean cancelOrder(String foodID) {
        List<String> updatedOrders = new ArrayList<>();
        boolean orderFound = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(ORDER_LIST_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] order = line.split(",");

                // Check if the order matches the current user and food ID
                if (order.length >= 7 && order[0].equals(foodID) && order[2].equals(this.customerID)) {
                    orderFound = true;
                    System.out.println("Order " + foodID + " canceled.");
                    continue;  // Skip writing this order (delete it)
                }

                updatedOrders.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading order list: " + e.getMessage());
            return false;
        }

        // If order found, rewrite the file without the canceled order
        if (orderFound) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(ORDER_LIST_FILE))) {
                for (String order : updatedOrders) {
                    writer.write(order);
                    writer.newLine();
                }
                System.out.println("Order list updated successfully.");
                return true;
            } catch (IOException e) {
                System.err.println("Error updating order list: " + e.getMessage());
            }
        } else {
            System.out.println("No matching order found for cancellation.");
        }

        return false;
    }
}
