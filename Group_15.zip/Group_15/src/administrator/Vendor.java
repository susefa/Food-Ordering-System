/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;

/**
 *
 * @author Umid
 */
public class Vendor extends User {
    public Vendor(String name, String userId, String email, String username, String password) {
        super(name, userId, email, username, password, "Vendor");
    }
}

