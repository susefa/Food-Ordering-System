package manager;

public class RatinRunnerStarts {

    public static String getStars(String rating) {
        try {
            int stars = Integer.parseInt(rating.trim());
            if (stars >= 1 && stars <= 5) {
                return "★".repeat(stars); // Repeat '★' based on rating
            }
        } catch (NumberFormatException e) {
        }
        return ""; 
    }
}
