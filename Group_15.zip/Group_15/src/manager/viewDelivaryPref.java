package manager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class viewDelivaryPref extends javax.swing.JFrame {
    private DefaultTableModel model;

    public viewDelivaryPref() {
        initComponents();
        model = new DefaultTableModel(new Object[]{"Runner name", "Runner ID","Order ID", "Customer Review", "Runner Rate"}, 0);
        jTable1.setModel(model);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BackToMenu = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        loadDataBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        SearchField = new javax.swing.JTextField();
        searchBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BackToMenu.setBackground(new java.awt.Color(107, 49, 57));
        BackToMenu.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        BackToMenu.setText("Back to menu");
        BackToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackToMenuActionPerformed(evt);
            }
        });
        getContentPane().add(BackToMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 440, 145, 40));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("View delivery preformance");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, -1));

        jTable1.setBackground(new java.awt.Color(102, 102, 102));
        jTable1.setForeground(new java.awt.Color(102, 102, 102));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Runner name", "runner id", "order id", "customer review", "runner rate"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 500, 290));

        loadDataBtn.setBackground(new java.awt.Color(107, 49, 57));
        loadDataBtn.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        loadDataBtn.setText("Load Delivary data");
        loadDataBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadDataBtnActionPerformed(evt);
            }
        });
        getContentPane().add(loadDataBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 170, 40));

        jLabel1.setText("serch using runner id");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 120, -1));

        SearchField.setBackground(new java.awt.Color(102, 102, 102));
        SearchField.setForeground(new java.awt.Color(102, 102, 102));
        SearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchFieldActionPerformed(evt);
            }
        });
        getContentPane().add(SearchField, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 80, 390, 30));

        searchBtn.setBackground(new java.awt.Color(107, 49, 57));
        searchBtn.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        searchBtn.setText("Search");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });
        getContentPane().add(searchBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(112, 80, 100, -1));

        jLabel3.setText("please load data first");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void BackToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackToMenuActionPerformed
        // TODO add your handling code here:
        managerMain menu = new managerMain();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackToMenuActionPerformed

    private void loadDataBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadDataBtnActionPerformed
        // TODO add your handling code here:
        loadData();
    }//GEN-LAST:event_loadDataBtnActionPerformed
    private String getStars(String review) {
    try {
        int rating = Integer.parseInt(review.trim()); // Ensure it's a valid number
        if (rating < 1 || rating > 5) {
            return "-"; // Return a dash if rating is out of range
        }
        return "⭐".repeat(rating); // Repeat the star symbol based on rating
    } catch (NumberFormatException e) {
        return "-"; // Return a dash if parsing fails
    }
}
    
private void loadData() {
    model.setRowCount(0); // Clear existing table data  
    try (BufferedReader br = new BufferedReader(new FileReader("C:\\javat\\JavaAssignment\\src\\Review_Runner"))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 8) { // Ensure data has all expected columns
                String runnerName = parts[6].trim();
                String runnerId = parts[5].trim();
                String orderId = parts[0].trim();
                String rating = parts[7].trim(); // Assuming rating is in column 8
                String stars = getStars(rating); // Convert rating to stars          
                model.addRow(new Object[]{runnerName, runnerId, orderId, rating, stars});
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
    }
}

    
    private void searchRunner() {
        
    String searchId = SearchField.getText().trim();
    if (searchId.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter a Runner ID to search.");
        return; // Stop execution if no input is provided
    }   
    model.setRowCount(0); // Clear table before displaying search results
    try (BufferedReader br = new BufferedReader(new FileReader("C:\\javat\\JavaAssignment\\src\\Review_Runner"))) {
        String line;
        boolean found = false;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 8) { 
                String runnername = parts[6].trim();
                String runnerId = parts[5].trim();
                String orderId = parts[0].trim();
                String review = parts[7].trim();
                
                if (runnerId.equalsIgnoreCase(searchId)) { // Case-insensitive search
                    String stars = getStars(review);
                    model.addRow(new Object[]{runnername,runnerId ,orderId, review, stars});
                    found = true;
                }
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(this, "No matching records found for Runner ID: " + searchId);
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error searching runner: " + e.getMessage());
    }
}
 
    
    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        // TODO add your handling code here:
        searchRunner();
    }//GEN-LAST:event_searchBtnActionPerformed

    private void SearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(viewDelivaryPref.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(viewDelivaryPref.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(viewDelivaryPref.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(viewDelivaryPref.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new viewDelivaryPref().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackToMenu;
    private javax.swing.JTextField SearchField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton loadDataBtn;
    private javax.swing.JButton searchBtn;
    // End of variables declaration//GEN-END:variables
}
